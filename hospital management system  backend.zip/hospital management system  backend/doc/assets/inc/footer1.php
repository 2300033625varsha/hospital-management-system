<footer class="footer footer-alt">
            2020 - <?php echo date ('Y');?> &copy; Hospital Management System. Developed By Martin Mbithi Nzilani</a> 
</footer>