<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                2020 - <?php echo date('Y'); ?> &copy; Hospital Management Information System. Developed By Martin Mbithi Nzilani</a>
            </div>

        </div>
    </div>
</footer>